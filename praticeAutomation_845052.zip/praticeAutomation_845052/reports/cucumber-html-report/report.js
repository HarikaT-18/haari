$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("automation_Practice.feature");
formatter.feature({
  "line": 1,
  "name": "Automation Website",
  "description": "",
  "id": "automation-website",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "#1",
  "description": "Register with valid data",
  "id": "automation-website;#1",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "the user register using \"bltcts55627@gmail.com\" and \"Asvthoraipakkam9877\"",
  "keyword": "Then "
});
formatter.match({
  "location": "testcucumber.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 19047550422,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 6547221984,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "bltcts55627@gmail.com",
      "offset": 25
    },
    {
      "val": "Asvthoraipakkam9877",
      "offset": 53
    }
  ],
  "location": "testcucumber.the_user_register_using_and(String,String)"
});
formatter.result({
  "duration": 174005711436,
  "error_message": "java.lang.NullPointerException\r\n\tat PAGES.logout_page.logout(logout_page.java:27)\r\n\tat PAGES.logout_page.clk_logout(logout_page.java:32)\r\n\tat STEP_DEF_PKG.testcucumber.the_user_register_using_and(testcucumber.java:70)\r\n\tat ✽.Then the user register using \"bltcts55627@gmail.com\" and \"Asvthoraipakkam9877\"(automation_Practice.feature:7)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 11,
  "name": "#2",
  "description": "Register with Invalid data",
  "id": "automation-website;#2",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "the user register using \"bltcts55@gmail.com\" and \"Asvthoraipakkam9877\"",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "Displays an error message that already registered",
  "keyword": "Then "
});
formatter.match({
  "location": "testcucumber.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 9608020402,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 1446383139,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "bltcts55@gmail.com",
      "offset": 25
    },
    {
      "val": "Asvthoraipakkam9877",
      "offset": 50
    }
  ],
  "location": "testcucumber.the_user_register_using_and(String,String)"
});
formatter.result({
  "duration": 10376100478,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.Displays_an_error_message_that_already_registered()"
});
formatter.result({
  "duration": 227008,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "#3",
  "description": "login with Valid data",
  "id": "automation-website;#3",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 22,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "user login using \"user45@gmail.com\" and \"mohankumar@6045\"",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "click on the login button user go to the next page",
  "keyword": "Then "
});
formatter.match({
  "location": "testcucumber.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 17138892344,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 2679119932,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "user45@gmail.com",
      "offset": 18
    },
    {
      "val": "mohankumar@6045",
      "offset": 41
    }
  ],
  "location": "testcucumber.user_login_using_and(String,String)"
});
formatter.result({
  "duration": 13000333872,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.click_on_the_login_button_user_go_to_the_next_page()"
});
formatter.result({
  "duration": 884488,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "#4",
  "description": "shop and add in the Automation website",
  "id": "automation-website;#4",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "user login using \"user45@gmail.com\" and \"mohankumar@6045\"",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "user click on the shop button and click on the add to cart button",
  "keyword": "Then "
});
formatter.match({
  "location": "testcucumber.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 50379843099,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 10801344059,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "user45@gmail.com",
      "offset": 18
    },
    {
      "val": "mohankumar@6045",
      "offset": 41
    }
  ],
  "location": "testcucumber.user_login_using_and(String,String)"
});
formatter.result({
  "duration": 15306134179,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.user_click_on_the_shop_button_and_click_on_the_add_to_cart_button()"
});
formatter.result({
  "duration": 27668458383,
  "status": "passed"
});
formatter.scenario({
  "line": 36,
  "name": "#5",
  "description": "Open Demo Suite for registration",
  "id": "automation-website;#5",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 38,
  "name": "the user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "the user open my Account page to register",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "user login using \"user45@gmail.com\" and \"mohankumar@6045\"",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "user click on the Demo site and enters the details using excel data",
  "keyword": "Then "
});
formatter.match({
  "location": "testcucumber.the_user_launch_the_Chrome_application()"
});
formatter.result({
  "duration": 30023839510,
  "status": "passed"
});
formatter.match({
  "location": "testcucumber.the_user_open_my_Account_page_to_register()"
});
formatter.result({
  "duration": 2169328381,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "user45@gmail.com",
      "offset": 18
    },
    {
      "val": "mohankumar@6045",
      "offset": 41
    }
  ],
  "location": "testcucumber.user_login_using_and(String,String)"
});
formatter.result({
  "duration": 14104388871,
  "error_message": "org.openqa.selenium.ElementClickInterceptedException: element click intercepted: Element \u003cinput type\u003d\"submit\" class\u003d\"woocommerce-Button button\" name\u003d\"login\" value\u003d\"Login\"\u003e is not clickable at point (162, 65). Other element would receive the click: \u003cheader id\u003d\"header\" class\u003d\"pagewidth clearfix header-on-scroll\" itemscope\u003d\"itemscope\" itemtype\u003d\"https://schema.org/WPHeader\"\u003e...\u003c/header\u003e\n  (Session info: chrome\u003d80.0.3987.149)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027LENOVO-PC\u0027, ip: \u0027192.168.42.39\u0027, os.name: \u0027Windows 8.1\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.3\u0027, java.version: \u002713.0.1\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 80.0.3987.149, chrome: {chromedriverVersion: 80.0.3987.106 (f68069574609..., userDataDir: C:\\Users\\HARIKA~1\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:64458}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: 64a55326fe110b39cadbb3217c3e2557\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:500)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:481)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat PAGES.registration_page.clk_submit(registration_page.java:61)\r\n\tat PAGES.registration_page.login(registration_page.java:75)\r\n\tat STEP_DEF_PKG.testcucumber.user_login_using_and(testcucumber.java:82)\r\n\tat ✽.Then user login using \"user45@gmail.com\" and \"mohankumar@6045\"(automation_Practice.feature:40)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "testcucumber.user_click_on_the_Demo_site_and_enters_the_details_using_excel_data()"
});
formatter.result({
  "status": "skipped"
});
});